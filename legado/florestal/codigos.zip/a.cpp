#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    ll n;
    ll ans = 0;
    cin >> n;
    for (ll i = 5; i<=n; i+=10) ans++;
    for (ll i = 10; i<=n; i+=10) ans += log10(i);
    cout << ans << endl;    
}