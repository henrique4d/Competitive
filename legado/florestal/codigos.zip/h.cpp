#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007

int main(){
    ll n;
    cin >> n;
    n ^= (1LL<<60)-1;
    cout << n << endl;
}